export class Customer {
    id: any;
	  name: any;
	  address: any;
	  age: any;
	  accType: any;
  }
  